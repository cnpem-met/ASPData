/* Note:  Microsoft Corporation is not the original author of these script files. Microsoft obtained
the original file from http://github.com/jquery/globalize under the license that is referred to below. That
license and the other notices below are provided for informational purposes only and are not
the license terms under which Microsoft distributes the files.  Microsoft grants you the right
to use the files for the sole purpose of using the files in conjunction with the Microsoft
product with which it was distributed subject to that product�s End User License Agreement.
Unless applicable law gives you more rights, Microsoft reserves all other rights to the files
not expressly granted by Microsoft, whether by implication, estoppel or otherwise.
*/
/*!
* Globalize Culture pt-BR
*
* http://github.com/jquery/globalize
*
* Copyright Software Freedom Conservancy, Inc.
* ------------------------------------------------------------------------------------
* MIT License
* Permission is hereby granted, free of charge, to any person obtaining
* a copy of this software and associated documentation files (the
* "Software"), to deal in the Software without restriction, including
* without limitation the rights to use, copy, modify, merge, publish,
* distribute, sublicense, and/or sell copies of the Software, and to
* permit persons to whom the Software is furnished to do so, subject to
* the following conditions:
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
* LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
* OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
* WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
* ------------------------------------------------------------------------------------
*/
(function(b){var a;if(typeof require!=="undefined"&&typeof exports!=="undefined"&&typeof module!=="undefined")a=require("globalize");else a=b.Globalize;a.addCultureInfo("pt-BR","default",{name:"pt-BR",englishName:"Portuguese (Brazil)",nativeName:"Portugu\u00eas (Brasil)",language:"pt",numberFormat:{",":".",".":",",NaN:"NaN (N\u00e3o \u00e9 um n\u00famero)",negativeInfinity:"-Infinito",positiveInfinity:"+Infinito",percent:{pattern:["-n%","n%"],",":".",".":","},currency:{pattern:["-$ n","$ n"],",":".",".":",",symbol:"R$"}},calendars:{standard:{days:{names:["domingo","segunda-feira","ter\u00e7a-feira","quarta-feira","quinta-feira","sexta-feira","s\u00e1bado"],namesAbbr:["dom","seg","ter","qua","qui","sex","s\u00e1b"],namesShort:["D","S","T","Q","Q","S","S"]},months:{names:["janeiro","fevereiro","mar\u00e7o","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro",""],namesAbbr:["jan","fev","mar","abr","mai","jun","jul","ago","set","out","nov","dez",""]},AM:null,PM:null,eras:[{name:"d.C.",start:null,offset:0}],patterns:{d:"dd/MM/yyyy",D:"dddd, d' de 'MMMM' de 'yyyy",t:"HH:mm",T:"HH:mm:ss",f:"dddd, d' de 'MMMM' de 'yyyy HH:mm",F:"dddd, d' de 'MMMM' de 'yyyy HH:mm:ss",M:"dd' de 'MMMM",Y:"MMMM' de 'yyyy"}}}})})(this)